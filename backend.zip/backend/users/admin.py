from django.contrib import admin

from users.models import Follow

admin.site.register(Follow)
